import bangundatar

print("## Perhitungan Persegi ##")
bangundatar.l_persegi(10)

print("## Perhitungan Persegi Panjang ##")
bangundatar.l_persegi_panjang(10,6)

print("## Segitiga ##")
bangundatar.l_segitiga(10,8)

print("## Lingkaran ##")
bangundatar.l_lingkaran(10)

print("## Jajar Genjang ##")
bangundatar.l_jajar_genjang(10,4,5)

print("## Belah Ketupat ##")
bangundatar.l_belah_ketupat(10,2,6)

print("## Layang Layang ##")
bangundatar.l_layang_layang(10,4,5,3)