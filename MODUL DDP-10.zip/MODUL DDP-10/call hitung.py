import hitung

print('## Pertambahan ##')
hitung.tambah(4, 3)

print('## Pergurangan ##')
hitung.kurang(5, 2)

print('## Perkalian ##')
hitung.kali(8, 5)

print('## Pembagian ##')
hitung.bagi(8, 4)

print('## Perpangkatan ##')
hitung.pangkat(4, 3)