import bangunruang

print("### Kubus ###")
bangunruang.kubus(3)

print("### Balok ###")
bangunruang.balok(2, 4, 7)

print("### Tabung ###")
bangunruang.tabung(5, 8)

print("### Prisma ###")
bangunruang.prisma(9, 4, 7)

print("### Bola ###")
bangunruang.bola(6)